from flask import Blueprint, request, jsonify
from data import users

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    if users.get(username) == password:
        return jsonify({"message": "Login successful", "token": "xyz"})
    return jsonify({"message": "Invalid credentials"}), 401