from flask import Blueprint, jsonify, request
from data import accounts

account_bp = Blueprint('account', __name__)

@account_bp.route('/accounts', methods=['GET'])
def get_accounts():
    return jsonify(accounts)

@account_bp.route('/accounts/<int:id>/status', methods=['POST'])
def update_status(id):
    data = request.get_json()
    status = data.get("status")

    for acc in accounts:
        if acc["id"] == id:
            acc["status"] = status
            return jsonify({"message": "Status updated", "account": acc})
    return jsonify({"message": "Account not found"}), 404