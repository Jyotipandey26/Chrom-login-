accounts = [
    {"id": 1, "company": "TechCorp", "matchScore": 86, "status": "Target"},
    {"id": 2, "company": "DataSoft", "matchScore": 72, "status": "Not Target"},
    {"id": 3, "company": "InnoTech", "matchScore": 93, "status": "Target"}
]

users = {
    "user1": "pass123"
}