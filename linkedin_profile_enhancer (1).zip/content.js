(function () {
  const data = {
    companyName: "TechCorp",
    matchScore: 86,
    accountStatus: "Target"
  };

  const widget = document.createElement("div");
  widget.style.position = "fixed";
  widget.style.top = "100px";
  widget.style.right = "20px";
  widget.style.width = "280px";
  widget.style.backgroundColor = "#fff";
  widget.style.border = "1px solid #ccc";
  widget.style.borderRadius = "8px";
  widget.style.padding = "15px";
  widget.style.boxShadow = "0 4px 8px rgba(0,0,0,0.1)";
  widget.style.zIndex = "9999";
  widget.innerHTML = `
    <strong>${data.companyName}</strong><br><br>
    Match Score:
    <div style="background:#eee;border-radius:4px;overflow:hidden;">
      <div style="width:${data.matchScore}%;background:#4caf50;padding:4px;color:white;text-align:center;">
        ${data.matchScore}%
      </div>
    </div><br>
    <span style="padding:4px 8px;border-radius:4px;color:white;background-color:${
      data.accountStatus === "Target" ? "green" : "red"
    };">
      ${data.accountStatus}
    </span>
  `;

  document.body.appendChild(widget);
})();